import React, { useState } from 'react';
import { useSelector } from 'react-redux';
import { Link, useParams } from 'react-router-dom';
import "./BrowseBooks.css";

function BrowseBooks() {
    const books = useSelector((state) => state.books.books); 
    const { category } = useParams(); // Extract category from the URL params if needed

    // Filter books based on category
    const filteredBooks = Array.isArray(books) && category 
        ? books.filter((book) => book.category === category) 
        : books;

    if (!Array.isArray(filteredBooks)) {
        return <div>Something went wrong, no books available.</div>;
    }

    return (
        <div className="container">
            <h1>{category ? `${category} Books` : "All Books"}</h1>
            <ul>
                {filteredBooks.map((book) => (
                    <li key={book.id}>
                        <h3>{book.title}</h3>
                        <p>{book.author}</p>
                        <Link to={`/book/${book.id}`}>View Details</Link>
                    </li>
                ))}
            </ul>
        </div>
    );
}

export default BrowseBooks;
