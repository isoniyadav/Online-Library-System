import React from "react";
import { useSelector } from "react-redux";
import { useParams } from "react-router-dom";
import { Link } from "react-router-dom";
import "./BookDetails.css";

function BookDetails() {
  const { id } = useParams(); 
  console.log("id from useParams:", id);

  
  const books = useSelector((state) => state.books);
  console.log("Books in Redux store:", books);

  const book = Array.isArray(books) ? books.find((b) => b.id === parseInt(id)) : null;

   if (!book) {
    console.log("Book not found for id:", id);
    return <p>Book not found</p>;
   }

  return (
    <div className="container">
      <h1>{book.title}</h1>
      <p><strong>Author:</strong> {book.author}</p>
      <p><strong>Description:</strong> {book.description}</p>
      <p><strong>Rating:</strong> {book.rating}</p>
      <Link to="/browse">Back to Browse</Link>
    </div>
  );
}

export default BookDetails;
