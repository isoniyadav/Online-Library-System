import React from "react";
import "./Home.css";
import { Link } from "react-router-dom";

function Home(){
    return(
        <div className="container">
            <h1>Welcome to the Online Library</h1>
            <h2>Book Categories</h2>
             <ul>
                 <li><Link to="/books/Fiction">Fiction</Link></li>
                 <li><Link to="/books/Non-Fiction">Non-Fiction</Link></li>
                <li><Link to="/books/Sci-Fi">Sci-Fi</Link></li>
            </ul>
             <h2>Popular Books</h2>
             <p>Explore some popular titles below!</p>
        </div>
    );
}
export default Home;
