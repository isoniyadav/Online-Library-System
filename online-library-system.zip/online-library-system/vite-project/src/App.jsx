import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Home from './Pages/Home';
import Navbar from './Components/Navbar';
import BookDetails from './Pages/BookDetails';
import BrowseBooks from './Pages/BrowseBooks';
import NotFound from './Pages/NotFound';
import AddBook from './Pages/AddBook';
import "./style.css";

function App(){
  return (
    <Router>
     <Navbar />
     <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/browse" element={<BrowseBooks />} />
      <Route path="/books/:category" element={<BrowseBooks />} />
      <Route path="/book/:id" element={<BookDetails />} />
      <Route path="/add" element={<AddBook />} />
      <Route path="*" element={<NotFound />} />
     </Routes>
   </Router>
  )
}
export default App;
